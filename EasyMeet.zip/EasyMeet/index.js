  socket.on("private message", (message, room, sender, reciever) => {
    io.to(room).emit("private message", message, sender, reciever);
  });
  socket.on("new invitation", invitation => {
    io.emit("new invitation", invitation);
    console.log(`${invitation.from} invited ${invitation.to} to the room ${invitation.room}`);
  });
});

server.listen(3000, () => {
  console.log("server started");
});