I made this video conferencing app called EasyMeet! 
### Features
- Chat Box
- Private Messaging
- Inviting

... and more!
You can see a guide on how to use this in the guide.md file, or go to https://easymeet.ruiwenge2.repl.co/help. To start, [sign up](https://easymeet.ruiwenge2.repl.co/signup)!

Even though your video and audio are off by default, you have to give access to your video and microphone to join. To see someone's name in the meet, hover your cursor over their video.

*Note: To create an account, you must open the website in a new tab.*

### I hope you like it!